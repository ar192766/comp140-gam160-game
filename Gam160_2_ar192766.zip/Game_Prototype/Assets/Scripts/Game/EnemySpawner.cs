﻿using UnityEngine;
using System.Collections;

public class EnemySpawner : MonoBehaviour 
{
	public float spawnCountDown = 3f ;
	public bool respawnReady;
 	GameObject Grunt_1;
	public Vector3[] spawnPosition;
	public int positionNumber;
    public bool increaseSpawn;
    public float gameTimer;

	void Start () 
	{
		Grunt_1 = Resources.Load("Grunt_1") as GameObject;
        //Enemy spawn locations
		spawnPosition[0] = new Vector3(-4.45f, 1.28f, 54.99f);
		spawnPosition[1] = new Vector3(-2.8f, 1.28f, 54.99f);
		spawnPosition[2] = new Vector3(-1.14f, 1.28f, 54.99f);
		spawnPosition[3] = new Vector3(0.57f, 1.28f, 54.99f);
		spawnPosition[4] = new Vector3(2.3f, 1.28f, 54.99f);
		spawnPosition[5] = new Vector3(4.05f, 1.28f, 54.99f);
		spawnPosition[6] = new Vector3(5.57f, 1.28f, 54.99f);
		spawnPosition[7] = new Vector3(7.19f, 1.28f, 54.99f);	
	}


	void Update ()
	{
		spawnCountDown -= 1f * Time.deltaTime;
		positionNumber = Random.Range(0, 7);

		if(spawnCountDown < 0f && TownHealth.townDestroyed == false)
		{
			Instantiate(Grunt_1,spawnPosition[positionNumber], Quaternion.identity);

            if (increaseSpawn == false)
            {
                spawnCountDown = 1.5f;
            }
		}

		if(spawnCountDown == 0f)
		{
			respawnReady = true;
		}

        gameTimer += 1f * Time.deltaTime;
	}

    void IncreaseEnemy()
    {
        if (gameTimer > 100f)
        {
            increaseSpawn = true;

        }
    }

}
