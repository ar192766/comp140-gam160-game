﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class GameOver : MonoBehaviour 
{
	public Text duplicate_Seconds;
	public Text duplicate_Minutes;
	public Animator gameOverImage;

	void Start () 
	{
		duplicate_Minutes = GameObject.FindGameObjectWithTag("DM").GetComponent<Text>();
		duplicate_Seconds = GameObject.FindGameObjectWithTag("DS").GetComponent<Text>();
	}
	

	void Update () 
	{
		if(TownHealth.townDestroyed == true)
		{
			duplicate_Seconds.text = Timer.seconds.ToString("00");
			duplicate_Minutes.text = Timer.minutes.ToString("00");
			gameOverImage.SetBool("IsOver", true);
		}
	}
}
