﻿using UnityEngine;
using System.Collections;

public class Grunt_1 : MonoBehaviour 
{
	public string spawners = "none";
	public GameObject[] spawnerPositions;
	public int spawnNumber;
	public NavMeshAgent agent;

	void Start () 
	{
		spawnerPositions = GameObject.FindGameObjectsWithTag("AIPath");
		agent = agent.GetComponent<NavMeshAgent>();
		spawnNumber = Random.Range(1,5);
	}

	void Update () 
	{
        // Checking number for enemy to pick a path on spawn
		if(spawnNumber == 1)
		{
			spawners = "Spawner 1";
		}
		else if(spawnNumber == 2)
		{
			spawners = "Spawner 2";
		}
		else if(spawnNumber == 3)
		{
			spawners = "Spawner 3";
		}
		else if(spawnNumber == 4)
		{
			spawners = "Spawner 4";
		}
		else if(spawnNumber == 5)
		{
			spawners = "Spawner 5";
		}
		SpawnPick();

		if(TownHealth.townDestroyed == true)
		{
			Destroy(gameObject);
		}
				
	}

	void SpawnPick()
	{// Setting destination for all spawners
		switch(spawners)
		{
		case "Spawner 1":
			agent.destination = spawnerPositions[0].transform.position;
			break;

		case "Spawner 2":
			agent.destination = spawnerPositions[1].transform.position;
			break;

		case "Spawner 3":
			agent.destination = spawnerPositions[2].transform.position;
			break;

		case "Spawner 4":
			agent.destination = spawnerPositions[3].transform.position;
			break;

		case "Spawner 5":
			agent.destination = spawnerPositions[4].transform.position;
			break;

		}

	}

	void OnTriggerEnter(Collider other)
	{
		if(other.tag == "Magic")
		{
			Destroy(other.gameObject);
			Destroy(gameObject);
		}
	}
}
