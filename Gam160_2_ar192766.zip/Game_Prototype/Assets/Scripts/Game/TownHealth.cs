﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class TownHealth : MonoBehaviour 
{
	public Image t_Health;
	public float enemyDamage;
	public static bool townDestroyed;
	public bool enemyPassed;	

	void Update () 
	{
        //Checks if An enemy has passed the player
		if(enemyPassed == true)
		{
			t_Health.fillAmount -= enemyDamage;
			enemyPassed = false;
			Debug.Log("hello");
		}
	    //Checking to see if town health = 0 if so the town has been destroyed
		if(t_Health.fillAmount == 0)
		{
			townDestroyed = true;
		}
	}

	void OnTriggerEnter(Collider other)
	{
		if(other.tag == "Grunt_1")
		{
			enemyDamage = Random.Range(0.05f, 0.15f);
			enemyPassed = true;  
		}
	}
}
