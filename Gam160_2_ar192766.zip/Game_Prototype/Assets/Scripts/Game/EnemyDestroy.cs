﻿using UnityEngine;
using System.Collections;

public class EnemyDestroy : MonoBehaviour
{
    void OnTriggerEnter(Collider other)
    {
        if (other.tag == "Grunt_1")
        {
            Destroy(other.gameObject);
        }
    }
}
