﻿using UnityEngine;
using System.Collections;

public class PlayerMovement : MonoBehaviour
{
    public GameObject player;
    public float speed;
    public float gravity;
    private Vector3 moveDirection;
    public CharacterController controller;
	
	void Start ()
    {
        controller = controller.GetComponent<CharacterController>();
	}
	

	void Update ()
    {//Lets the player move left and right
        if (controller.isGrounded)
        {
            moveDirection = new Vector3(Input.GetAxis("Horizontal"), 0);
            moveDirection = transform.TransformDirection(moveDirection);
            moveDirection *= speed;
        }

        moveDirection.y -= gravity * Time.deltaTime;
        controller.Move(moveDirection * Time.deltaTime);
	}
}
