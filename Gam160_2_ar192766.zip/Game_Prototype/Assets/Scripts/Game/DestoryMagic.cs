﻿using UnityEngine;
using System.Collections;

public class DestoryMagic : MonoBehaviour
{
	void Update () 
	{
		Destroy(gameObject, 2);
	}
}
