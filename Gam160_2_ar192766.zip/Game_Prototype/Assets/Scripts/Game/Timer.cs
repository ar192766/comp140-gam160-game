﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class Timer : MonoBehaviour
{
    public Text timer_Seconds;
    public static float seconds;

    public Text timer_Minutes;
    public static float minutes;

    public static bool spawnIncrease;

    void Start()
    {
        timer_Seconds = GameObject.FindGameObjectWithTag("TimerSeconds").GetComponent<Text>();
        timer_Minutes = GameObject.FindGameObjectWithTag("TimerMinutes").GetComponent<Text>();
    }


    void Update()
    {
        if (TownHealth.townDestroyed == false)
        {
            timer_Seconds.text = seconds.ToString("00");
            timer_Minutes.text = minutes.ToString("00");
            seconds += 1f * Time.deltaTime;
        }


        if (timer_Seconds.text == "60")
        {
            minutes += 1f;
            seconds = 0;
            spawnIncrease = true;
            StartCoroutine(SpawnIncreaseOff());
        }

    }

    IEnumerator SpawnIncreaseOff()
    {
        yield return new WaitForSeconds(0.2f);
        {
            spawnIncrease = false;
        }
    }
}
