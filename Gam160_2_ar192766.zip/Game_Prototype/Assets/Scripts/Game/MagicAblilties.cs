﻿using UnityEngine;
using System.Collections;

public class MagicAblilties : MonoBehaviour 
{
	public string magicAbilities = "none";
	GameObject magic1Prefab;
	GameObject magic2Prefab;
	GameObject magic3Prefab;
	GameObject magic4Prefab;

	public Transform magicSpawn;
	public float magicSpeed;
	public bool magicDelay;

	void Start () 
	{
		magic1Prefab = Resources.Load("Magic1") as GameObject;
		magic2Prefab = Resources.Load("Magic2") as GameObject;
		magic3Prefab = Resources.Load("Magic3") as GameObject;
		magic4Prefab = Resources.Load("Magic4") as GameObject;
	}

	void FixedUpdate()
	{
        //Checking to see if the player has presses any of these buttons
		if(Input.GetKeyDown(KeyCode.Alpha1))
		{
			magicAbilities = "Magic 1";
		}
		else if(Input.GetKeyDown(KeyCode.Alpha2))
		{
			magicAbilities = "Magic 2";
		}
		else if(Input.GetKeyDown(KeyCode.Alpha3))
		{
			magicAbilities = "Magic 3";
		}
		else if(Input.GetKeyDown(KeyCode.Alpha4))
		{
			magicAbilities = "Magic 4";
		}
		Magic1Firing();
	}
	
	void Magic1Firing()
	{//setting the 4 magic abilities
		switch(magicAbilities)
		{
		case "Magic 1":
			if(Input.GetKeyDown(KeyCode.Alpha1) && magicDelay == false)
			{
				GameObject Magic1 = Instantiate(magic1Prefab) as GameObject;
				Magic1.transform.position = magicSpawn.transform.position + Camera.main.transform.forward * 0.5f;

				Rigidbody rigidbody = Magic1.GetComponent<Rigidbody>();
				rigidbody.velocity = Camera.main.transform.forward * magicSpeed;
				magicDelay = true;
				StartCoroutine(MagicDelay());
			}
			break;

		case "Magic 2":
			if(Input.GetKeyDown(KeyCode.Alpha2) && magicDelay == false)
			{
				GameObject Magic2 = Instantiate(magic2Prefab) as GameObject;
				Magic2.transform.position = magicSpawn.transform.position + Camera.main.transform.forward * 0.5f;

				Rigidbody rigidbody = Magic2.GetComponent<Rigidbody>();
				rigidbody.velocity = Camera.main.transform.forward * magicSpeed;
				magicDelay = true;
				StartCoroutine(MagicDelay());
			}
			break;

		case "Magic 3":
			if(Input.GetKeyDown(KeyCode.Alpha3) && magicDelay == false)
			{
				GameObject Magic3 = Instantiate(magic3Prefab) as GameObject;
				Magic3.transform.position = magicSpawn.transform.position + Camera.main.transform.forward * 0.5f;

				Rigidbody rigidbody = Magic3.GetComponent<Rigidbody>();
				rigidbody.velocity = Camera.main.transform.forward * magicSpeed;
				magicDelay = true;
				StartCoroutine(MagicDelay());
			}
			break;

		case "Magic 4":
			if(Input.GetKeyDown(KeyCode.Alpha4) && magicDelay == false)
			{
				GameObject Magic4 = Instantiate(magic4Prefab) as GameObject;
				Magic4.transform.position = magicSpawn.transform.position + Camera.main.transform.forward * 0.5f;

				Rigidbody rigidbody = Magic4.GetComponent<Rigidbody>();
				rigidbody.velocity = Camera.main.transform.forward * magicSpeed;
				magicDelay = true;
				StartCoroutine(MagicDelay());
			}
			break;
		}


	
	}

	IEnumerator MagicDelay()
	{
		yield return new WaitForSeconds(0.5f);
		{
			magicDelay = false;
		}
	}

}
